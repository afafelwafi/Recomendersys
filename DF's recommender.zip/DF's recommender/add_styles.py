# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 12:43:05 2019

@author: afafe
"""

import db as dbb
import cv2
from PIL import Image
import glob
import numpy as np
import os 
import requests
import urllib
from io import BytesIO
import io
from PIL import ImageChops
import imagehash
products=dbb.get_products(7)
base_occ="C:/Users/afafe/Desktop/stage/Occasions/"

occasions_images=ReadFileImages(path)
path=base+occasions[0]
import matplotlib.pyplot as plt
    
occasions=['Mariage','Quotidien','Sortie','Travail','Vacances','Week-end']
style=['1. Classique','2. Creative','3. Work','4. Casual']

def ReadFileImages(strFolderName):
    image_list=[]
    st=os.path.join(strFolderName,"*.jpg")
    for filename in glob.glob(st):
        image_list.append(filename)
        
    return image_list

for p in products:
    k=0
    l=0
    try:
        t,m=add_style(p,style)
        k+=1
    except :
        print('no style')
        l+=1
    
 
    ##original_image:
classic=ReadFileImages(base+style[0])
creative=ReadFileImages(base+style[1])
work=ReadFileImages(base+style[2])
casual=ReadFileImages(base+style[3])
products_images=ReadFileImages("C:\\Users\\afafe\\Desktop\\stage\\DF's recommender\\products images")
styleless_products=ReadFileImages("C:\\Users\\afafe\\Desktop\\stage\\DF's recommender\\styleless products")
import time

for i,p in enumerate(products) :
    if i>191:
        print("product number"+str(i))
        add_style(p,style,Liste)
            
s=156
prducts={}
products['product_id']=''
products['style']=''

def add_corr(products):
    for p in products:
        p['custom']={}
        p['custom']['occasion']=''
        prod_id=p['product_id']
        for s in occasions:
            path=base_occ+s
            occasions_images=ReadFileImages(path)
            for t in occasions_images:
                t=t.split('\\')[1][:-4]
                if t==prod_id:
                    p['custom']['occasion']=s
            
           
                
        
            
    








def add_style(p,style,Liste):
    with urllib.request.urlopen(p['picture_url']) as url:
        f = io.BytesIO(url.read())
        im2 = Image.open(f)
        im2h=imagehash.average_hash(im2)
        start=time.time()
        for m in casual:
            try:
                im1=Image.open(m)
                im1h= imagehash.average_hash(im1)
                if im1h==im2h:
                   p['style']="casual"
                   break
                    #return m
            except:
                pass
        end=time.time()
    
        print("casual checked time:"+str(end-start))
        start=end
        if p['style']==None:
            for m in creative:
                try:
                    im1=Image.open(m)
                    im1h= imagehash.average_hash(im1)
                    if im1h==im2h:
                        p['style']="creative"
                        break
                        
                        #return m
                except:
                    pass
            end=time.time()
    
            print("creative checked time:"+str(end-start))
            start=end
            if p['style']==None:
                for m in work:
                    try:
                        im1=Image.open(m)
                        im1h= imagehash.average_hash(im1)
                        if im1h==im2h:
                            p['style']="work"
                            break
                            
                            #return m
                    except:
                        pass
                end=time.time()
                print("work checked time:"+str(end-start))
                start=end
                if p['style']==None:
                    for m in classic:
                        try:
                            im1=Image.open(m)
                            im1h= imagehash.average_hash(im1)
                            if im1h==im2h:
                                p['style']="classic"
                                break
                                
                                #return m
                        except:
                            pass
                    end=time.time()
                    print("classic checked time:"+str(end-start))
                    if p['style']==None:
                        Liste.append(p)
                        
                        print("no style")
            

            
Liste=[]          
    
##all products :
base="C:/Users/afafe/Desktop/stage/Styles/"
classic=ReadFileImages(base+style[0])
creative=ReadFileImages(base+style[1])
work=ReadFileImages(base+style[2])
casual=ReadFileImages(base+style[3])
for p in products :
    if p['style']==None and p in Liste:
        for s in style:
            file=ReadFileImages(base+s)
            for t in file:
                t=t.split('\\')[1][:-4]
                if t==p['product_id']:
                    p['style']=s
for p in products:
    p['custom']['style']=''
    if p['style'] in style:
        p['custom']['style']=p['style'][3:]
    if p['style'] in ['casual','classic','work','creative']:
        p['custom']['style']=p['style'][0].upper()+p['style'][1:]
    
    




